﻿using System;
using System;
using System.Collections.Generic;
using Kvíz.Models;
using Kvíz.Interface;

namespace Kvíz
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Feltolt.FelValFeltolt();
            Feltolt.IgazHamisFeltolt();
            Feltolt.TippelosFeltolt();

            bool futtatas = true;

            while (futtatas)
            {
                Console.Clear();
                Console.WriteLine("1. Játék indítása");
                Console.WriteLine("2. Kilépés");
                Console.Write("Válassz opciót (1-2): ");

                string menu = Console.ReadLine();

                if (menu == "1")
                {
                    KvizInditasa();
                }
                else if (menu == "2")
                {
                    futtatas = false;
                    Console.ReadKey();
                }
            }
        }

        static void KvizInditasa()
        {
            Console.Clear();

            int db = 0;
            Console.Write("Hány kérdést szeretnél?: ");
            string kerdesdb = Console.ReadLine();
            if (int.TryParse(kerdesdb, out int beirtDb) && beirtDb > 0) db = beirtDb;

            Console.WriteLine("\nMilyen típusú kérdések legyenek?");
            Console.WriteLine("1. Feleletválasztós");
            Console.WriteLine("2. Igaz-Hamis");
            Console.WriteLine("3. Tippelős");
            Console.WriteLine("4. Vegyes");
            Console.Write("Válassz (1-4): ");
            string tipusValasz = Console.ReadLine();

            Type valasztottTipus = null;
            if (tipusValasz == "1") valasztottTipus = typeof(FelValKerdes);

            else if (tipusValasz == "2") valasztottTipus = typeof(IgazHamisKerdes);

            else if (tipusValasz == "3") valasztottTipus = typeof(TippelosKerdes);

            Console.Write("\nMilyen témakör legyen?: ");
            string temakor = Console.ReadLine();
            if (temakor == "") temakor = null;

            Feladatlap flap;

            if (valasztottTipus != null && temakor != null)
            {
                flap = new Feladatlap(db, valasztottTipus, temakor);
            }
            else if (valasztottTipus != null)
            {
                flap = new Feladatlap(db, valasztottTipus);
            }
            else if (temakor != null)
            {
                flap = new Feladatlap(db, temakor);
            }
            else
            {
                flap = new Feladatlap(db);
            }

            Console.Clear();

            int pont = flap.FeladatJatszas();

            Console.Clear();
            Console.WriteLine($"Gratulálok! Összesen {pont} pontot értél el.");
            Console.WriteLine("\nNyomj meg egy gombot a főmenübe való visszatéréshez...");
            Console.ReadKey();
        }
    }
}
