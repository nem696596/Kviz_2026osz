﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kvíz.Models
{
    abstract class Kerdes
    {
        public string Kszoveg { get; set; }
        public byte Pontszam { get; set; }
        public string Temakor { get; set; }

        abstract protected void Kiir();
        abstract protected byte Ellenorzes(object o);
        abstract protected object Bekeres();
    }
}
