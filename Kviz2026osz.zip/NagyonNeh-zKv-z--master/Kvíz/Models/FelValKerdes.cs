﻿using Kvíz.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kvíz.Models
{
    internal class FelValKerdes : Kerdes, Ikerdes
    {
        public static List<Ikerdes> FV = new List<Ikerdes>();
        public string[] Valaszok { get; }
        public byte Hvalasz { get; }
        public FelValKerdes(string s)
        {
            string[] adatok = s.Split(';');
            Valaszok = new string[4];
            Kszoveg = adatok[0];
            Valaszok[0] = adatok[1];
            Valaszok[1] = adatok[2];
            Valaszok[2] = adatok[3];
            Valaszok[3] = adatok[4];
            Hvalasz =byte.Parse(adatok[5]);
            Pontszam = byte.Parse(adatok[6]);
            Temakor = adatok[7];
        }
        public byte jatszas()
        {
            Kiir();
            return Ellenorzes(Bekeres());
        }

        protected override object Bekeres()
        {
            Console.WriteLine("Adja meg a helyes válasz számát (1-4):");
            byte hv;
            while (!byte.TryParse(Console.ReadLine(), out hv) || hv < 1 || hv > 4)
            {
                Console.WriteLine("Adjon meg egy valid számot (1-4):");
            }

            return hv;
        }

        protected override byte Ellenorzes(object o)
        {
            if ((byte)o == Hvalasz)
            {
                return Pontszam;
            }
            else
            {
                return 0;
            }
        }

        protected override void Kiir()
        {
            Console.Clear();
            Console.WriteLine($"{Kszoveg}");
            Console.WriteLine($"1: {Valaszok[0]}\t 2: {Valaszok[1]}\t 3: {Valaszok[2]}\t 4: {Valaszok[3]}");
        }
    }
}
