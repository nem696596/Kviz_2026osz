﻿using Kvíz.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kvíz.Models
{
    internal class TippelosKerdes : Kerdes, Ikerdes
    {
        public static List<Ikerdes> T=new List<Ikerdes>();
        public int szazalek { get; set; }
        public double hvalasz { get; set; }
        public TippelosKerdes(string s)
        {
            string[] adatok = s.Split(';');
            Kszoveg=adatok[0];
            hvalasz=double.Parse(adatok[1]);
            Pontszam=byte.Parse(adatok[2]);
            szazalek=int.Parse(adatok[3]);
            Temakor = adatok[4];
        }

        public byte jatszas()
        {
            Kiir();
            return Ellenorzes(Bekeres());
        }

        protected override object Bekeres()
        {
            Console.WriteLine("Adja meg a helyes választ:");
            object o = Console.ReadLine();

            return o;
        }

        protected override byte Ellenorzes(object o)
        {
            int tipp = int.Parse(o.ToString());
            if (Math.Abs(tipp - hvalasz) <= Math.Abs(hvalasz) * szazalek / 100.0) return Pontszam;
            return 0;
        }

        protected override void Kiir()
        {
            Console.Clear();
            Console.WriteLine($"{Kszoveg}");
        }
    }
}
