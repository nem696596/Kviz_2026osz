﻿using Kvíz.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kvíz.Models
{
    internal class Feladatlap
    {
        static public List<Ikerdes> K = new List<Ikerdes>();
        public List<Ikerdes> KivKerdes { get; set; }
        Random r = new Random();

        // 4. MENÜPONT: VEGYES
        public Feladatlap(int felDb)
        {
            if (K.Count < felDb) felDb = K.Count;
            KivKerdes = new List<Ikerdes>();

            do
            {
                int i = r.Next(0, K.Count);
                if (!KivKerdes.Contains(K[i])) KivKerdes.Add(K[i]);
            } while (KivKerdes.Count < felDb);
        }

        // 1. MENÜPONT: TÉMAKÖR ALAPJÁN
        public Feladatlap(int felDb, string temakor)
        {
            var kerdesek = K.Where(x => x.Temakor == temakor).ToList();
            if (kerdesek.Count == 0)
            {
                KivKerdes = new List<Ikerdes>();
                return;
            }

            if (kerdesek.Count < felDb) felDb = kerdesek.Count;
            KivKerdes = new List<Ikerdes>();

            do
            {
                int i = r.Next(0, kerdesek.Count);
                if (!KivKerdes.Contains(kerdesek[i])) KivKerdes.Add(kerdesek[i]);
            } while (KivKerdes.Count < felDb);
        }

        // 2. MENÜPONT: TÍPUS ALAPJÁN
        public Feladatlap(int felDb, Type tematipus)
        {
            var kerdesek = K.Where(x => x.GetType() == tematipus).ToList();
            if (kerdesek.Count == 0)
            {
                KivKerdes = new List<Ikerdes>();
                return;
            }

            if (kerdesek.Count < felDb) felDb = kerdesek.Count;
            KivKerdes = new List<Ikerdes>();

            do
            {
                int i = r.Next(0, kerdesek.Count);
                if (!KivKerdes.Contains(kerdesek[i])) KivKerdes.Add(kerdesek[i]);
            } while (KivKerdes.Count < felDb);
        }

        // 3. MENÜPONT: TÍPUS ÉS TÉMAKÖR ALAPJÁN
        public Feladatlap(int felDb, Type tematipus, string temakor)
        {
            var kerdesek = K.Where(x => x.GetType() == tematipus && x.Temakor == temakor).ToList();
            if (kerdesek.Count == 0)
            {
                KivKerdes = new List<Ikerdes>();
                return;
            }

            if (kerdesek.Count < felDb) felDb = kerdesek.Count;
            KivKerdes = new List<Ikerdes>();

            do
            {
                int i = r.Next(0, kerdesek.Count);
                if (!KivKerdes.Contains(kerdesek[i])) KivKerdes.Add(kerdesek[i]);
            } while (KivKerdes.Count < felDb);
        }

        public byte FeladatJatszas()
        {
            byte k = 0;
            if (KivKerdes == null) KivKerdes = new List<Ikerdes>();
            foreach (var item in KivKerdes)
            {
                k += item.jatszas();
            }
            Console.Clear();
            return k;
        }
    }
}
