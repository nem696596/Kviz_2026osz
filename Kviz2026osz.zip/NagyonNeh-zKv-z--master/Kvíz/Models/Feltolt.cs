﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kvíz.Models
{
    public class Feltolt
    {
        public static void FelValFeltolt()
        {
            foreach (var i in File.ReadAllLines("Data/FeleletValasztosKerdesBank.txt").ToList())
            {
                FelValKerdes F = new FelValKerdes(i);
                FelValKerdes.FV.Add(F);
                Feladatlap.K.Add(F);
            }
        }
        public static void IgazHamisFeltolt()
        {
            foreach (var i in File.ReadAllLines("Data/IgazHamisKerdesBank.txt").ToList())
            {
                IgazHamisKerdes F = new IgazHamisKerdes(i);
                IgazHamisKerdes.IH.Add(F);
                Feladatlap.K.Add(F);
            }
        }
        public static void TippelosFeltolt()
        {
            foreach (var i in File.ReadAllLines("Data/TippelosKerdesBank.txt").ToList())
            {
                TippelosKerdes F = new TippelosKerdes(i);
                TippelosKerdes.T.Add(F);
                Feladatlap.K.Add(F);
            }
        }
    }
}
