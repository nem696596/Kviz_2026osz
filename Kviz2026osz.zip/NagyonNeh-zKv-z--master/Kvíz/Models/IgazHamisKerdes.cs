﻿using Kvíz.Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kvíz.Models
{
    internal class IgazHamisKerdes : Kerdes,Ikerdes
    {
        public static List<Ikerdes> IH = new List<Ikerdes>();
        public bool valasz { get; set; }
        public bool hvalasz { get; set; }
        public IgazHamisKerdes(string s)
        {
            string[] adatok = s.Split(';');
            Kszoveg = adatok[0];
            if (adatok[1] == "1")
                hvalasz = true;
            else
                hvalasz = false;
            Pontszam = byte.Parse(adatok[2]);
            Temakor = adatok[3];
        }

        public byte jatszas()
        {
            Kiir();
            return Ellenorzes(Bekeres());
        }

        protected override void Kiir()
        {
            Console.Clear();
            Console.WriteLine($"{Kszoveg}");
        }

        protected override byte Ellenorzes(object o)
        {
            if (o is bool b && b == hvalasz)
                return Pontszam;
            return 0;
        }

        protected override object Bekeres()
        {
            Console.WriteLine("Adja meg a helyes választ 1/0 vagy true/false:");
            string beker = Console.ReadLine();

            while (true)
            {
                if (beker == "1" || beker == "true")
                {
                    return true;
                }

                if (beker == "0" || beker == "false")
                {
                    return false;
                }

                Console.WriteLine("Érvénytelen bemenet. Adj meg 1/0 vagy true/false:");
                beker = Console.ReadLine();
            }
        }
    }
}
