﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kvíz.Interface
{
    public interface Ikerdes
    {
        public string Temakor { get; set; }
        public byte jatszas();
    }
}
